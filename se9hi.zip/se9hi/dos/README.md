# dos
> A Nodejs based DoS/DDoS script.

## Usage

```bash
$ npm install

$ npm start
```

---

## API

> dos(url: string, quantity: number, delay: number): void

```js
dos('http://localhost:3000', 150, 500)

// 150 requests per 0.5 seconds
```

---